<?php /*********************************
Search Engine Doorway Generator (SEoDOR)
*                        Hosting Checker
Copyright © 2017, http://seodor.biz   */

header('Content-Type: text/html; charset=utf-8');

if(isset($_GET['check'])) { echo 'rewrite_ok'; die; }
if(isset($_GET['phpinfo'])) { phpinfo(); die; }

echo "<style>html{font-family: 'Trebuchet MS', Helvetica, Arial, sans-serif;color:#333;font-size:15px;padding: 10px;}</style>";

extension_loaded("mbstring") ? $mess = '<font color="green">OK</font>' : $mess = '<font color="red">Error!</font>';
echo '<b>MBString:</b> ' . $mess . '<br><br>';

(function_exists("iconv")) ? $mess = '<font color="green">OK</font>' : $mess = '<font color="red">Error!</font>';
echo '<b>iconv:</b> ' . $mess . '<br><br>';

(function_exists("parse_ini_file")) ? $mess = '<font color="green">OK</font>' : $mess = '<font color="red">Error!</font>';
echo '<b>parse_ini_file():</b> ' . $mess . '<br><br>';

(function_exists("curl_exec") && function_exists("curl_init")) ? $mess = '<font color="green">OK</font>' : $mess = '<font color="red">Error!</font>';
echo '<b>cURL:</b> ' . $mess . '<br><br>';

(function_exists("curl_multi_exec")) ? $mess = '<font color="green">OK</font>' : $mess = '<font color="red">Error!</font>';
echo '<b>curl_multi_exec():</b> ' . $mess . '<br><br>';

ini_get("allow_url_fopen") ? $mess = '<font color="green">OK</font>' : $mess = '<font color="red">Error!</font>';
echo '<b>allow_url_fopen:</b> ' . $mess . '<br><br>';

function_exists("simplexml_load_string") ? $mess = '<font color="green">OK</font>' : $mess = '<font color="red">Error!</font>';
echo '<b>SimpleXML:</b> ' . $mess . '<br><br>';

function_exists("json_decode") ? $mess = '<font color="green">OK</font>' : $mess = '<font color="red">Error!</font>';
echo '<b>JSON:</b> ' . $mess . '<br><br>';

extension_loaded('zip') ? $mess = '<font color="green">OK</font>' : $mess = '<font color="red">Error!</font> Требуется для автообновления парсеров и отложенной статики!';
echo '<b>ZipArchive:</b> ' . $mess . '<br><br>';

//extension_loaded('zlib') ? $mess = '<font color="green">OK</font>' : $mess = '<font color="red">Error!</font>';
//echo '<b>zlib:</b> ' . $mess . '<br><br>';

//function_exists("gzinflate") ? $mess = '<font color="green">OK</font>' : $mess = '<font color="red">Error!</font> Требуется для распаковки сжатых html-файлов (не критично, но желательно).';
//echo '<b>gzinflate:</b> ' . $mess . '<br><br>';

if (version_compare(phpversion(), '5.3.4', '>')) {$php = 1; $mess = phpversion() . ' <font color="green">OK</font>';}
else {$php = 0; $mess = phpversion() . ' <font color="red">Error!</font> (Min PHP VERSION 5.3.4)';}
echo '<b>PHP:</b> ' . $mess . '<br><br>';

extension_loaded("dom") ? $mess = '<font color="green">OK</font>' : $mess = '<font color="red">Error!</font> Требуется при парсинге сайтов.';
echo '<b>PHP5-DOM:</b> ' . $mess . '<br><br>';

function_exists("tidy_parse_string") ? $mess = '<font color="green">OK</font>' : $mess = '<font color="red">Error!</font> Требуется при парсинге сайтов (не критично, но желательно).';
echo '<b>Tidy:</b> ' . $mess . '<br><br>';

if(extension_loaded('pdo_sqlite')) {
	if (extension_loaded('sqlite') or extension_loaded('sqlite3')) $mess = '<font color="green">OK</font>'; else $mess = '<font color="red">Error!</font> Вместо SQLite можно использовать обычный кеш.';
} else $mess = '<font color="red">Error!</font> Не подключен драйвер PDO_SQLITE. Вместо SQLite можно использовать обычный кеш.';
echo '<b>SQLite:</b> ' . $mess . '<br><br>';

function_exists("imagecreatefromjpeg") ? $mess = '<font color="green">OK</font>' : $mess = '<font color="red">Error!</font> Библиотека GD требуется для функции "своих картинок".';
echo '<b>GD Support:</b> ' . $mess . '<br><br>';

@file_get_contents('http://'.$_SERVER['HTTP_HOST']. '/check_host/rewrite.html') == 'rewrite_ok' ? $mess = '<font color="green">OK</font>' : $mess = 'Перейдите по этому адресу <a href="rewrite.html">rewrite.html</a>, если увидели там <b>rewrite_ok</b> - то <b>Mod Rewrite</b> в порядке!';
echo '<b>Mod Rewrite:</b> ' . $mess . '<br><br>';